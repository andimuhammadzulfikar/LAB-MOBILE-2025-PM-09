package com.example.tugaspraktikum1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditEmail extends AppCompatActivity {
    EditText editText;
    Button button;
    ImageView ivBack;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_email);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");

        editText = findViewById(R.id.editEmail);
        button = findViewById(R.id.btnSimpan);
        ivBack = findViewById(R.id.kembaliProfil);

        if (user != null) {
            editText.setText(user.getEmail());
        }

        button.setOnClickListener(v -> {
            String emailBaru = editText.getText().toString();
            user.setEmail(emailBaru);
            Intent intent = new Intent();
            intent.putExtra("extra_user", user);
            setResult(RESULT_OK, intent);
            finish();
        });

        ivBack.setOnClickListener(v -> {
            Intent intent = new Intent(EditEmail.this, ProfilActivity.class);
            intent.putExtra("extra_user", user);
            startActivity(intent);
        });

    }
}