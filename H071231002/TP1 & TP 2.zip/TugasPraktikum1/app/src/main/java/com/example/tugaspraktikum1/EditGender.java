package com.example.tugaspraktikum1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditGender extends AppCompatActivity {
    RadioButton radioLaki, radioPerem, radioLain;
    RadioGroup radioGroup;
    Button btnSimpan;
    User user;
    ImageView ivBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_gender);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");

        radioGroup = findViewById(R.id.radioGroup);
        radioLaki = findViewById(R.id.radioLaki);
        radioPerem = findViewById(R.id.radioPerem);
        radioLain = findViewById(R.id.radioLain);
        btnSimpan = findViewById(R.id.btnSimpan);
        ivBack = findViewById(R.id.kembaliProfil);


        if (user != null) {
            String gender = user.getJenisKelamin();
            if (gender.equalsIgnoreCase("Laki-laki")) {
                radioLaki.setChecked(true);
            } else if (gender.equalsIgnoreCase("Perempuan")) {
                radioPerem.setChecked(true);
            } else {
                radioLain.setChecked(true);
            }
        }
        btnSimpan.setOnClickListener(v -> {
            String gender = "";
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId == R.id.radioLaki) {
                gender = "Laki-laki";
            } else if (selectedId == R.id.radioPerem) {
                gender = "Perempuan";
            } else if (selectedId == R.id.radioLain) {
                gender = "Lainnya";
            }

            user.setJenisKelamin(gender);

            Intent intent = new Intent();
            intent.putExtra("extra_user", user);
            setResult(RESULT_OK, intent);
            finish();
        });

        ivBack.setOnClickListener(v -> {
            Intent intent = new Intent(EditGender.this, ProfilActivity.class);
            intent.putExtra("extra_user", user);
            startActivity(intent);
        });


    }
}