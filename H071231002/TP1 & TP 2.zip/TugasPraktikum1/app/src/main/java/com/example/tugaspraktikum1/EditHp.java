package com.example.tugaspraktikum1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditHp extends AppCompatActivity {
    EditText editText;
    Button button;
    ImageView ivBack;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_hp);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");

        editText = findViewById(R.id.editNomor);
        button = findViewById(R.id.btnSimpan);
        ivBack = findViewById(R.id.kembaliProfil);

        if (user != null) {
            editText.setText(String.valueOf(user.getNoHandphone()));
        }

        button.setOnClickListener(v -> {
            try {
                int hpBaru = Integer.parseInt(editText.getText().toString());
                user.setNoHandphone(hpBaru);

                Intent intent = new Intent();
                intent.putExtra("extra_user", user);
                setResult(RESULT_OK, intent);
                finish();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Masukkan nomor yang valid", Toast.LENGTH_SHORT).show();
            }
        });

        ivBack.setOnClickListener(v -> {
            Intent intent = new Intent(EditHp.this, ProfilActivity.class);
            intent.putExtra("extra_user", user);
            startActivity(intent);
        });


    }
}