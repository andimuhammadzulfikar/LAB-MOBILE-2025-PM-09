package com.example.tugaspraktikum1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditNama extends AppCompatActivity {
    EditText editText;
    Button button;
    ImageView ivBack;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_nama);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");

        editText = findViewById(R.id.editNama);
        button = findViewById(R.id.btnSimpan);
        ivBack = findViewById(R.id.kembaliProfil);

        if (user != null) {
            editText.setText(user.getNama());
        }

        button.setOnClickListener(v -> {
            String namaBaru = editText.getText().toString();
            user.setNama(namaBaru);
            Intent intent = new Intent();
            intent.putExtra("extra_user", user);
            setResult(RESULT_OK, intent);
            finish();
        });


        ivBack.setOnClickListener(v -> {
            Intent intent = new Intent(EditNama.this, ProfilActivity.class);
            intent.putExtra("extra_user", user);
            startActivity(intent);
        });


    }
}