package com.example.tugaspraktikum1;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class EditTgglLahir extends AppCompatActivity {

    Button pilihTanggalBtn, simpanTanggalBtn;
    TextView tanggalTextView;
    String selectedDate = "";
    ImageView ivBack;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_tggl_lahir);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");

        pilihTanggalBtn = findViewById(R.id.pilihTanggalBtn);
        simpanTanggalBtn = findViewById(R.id.simpanTanggalBtn);
        tanggalTextView = findViewById(R.id.tanggalTextView);
        ivBack = findViewById(R.id.kembaliProfil);


        pilihTanggalBtn.setOnClickListener(v -> showDatePicker());

        simpanTanggalBtn.setOnClickListener(v -> {
            if (!selectedDate.isEmpty() && user != null) {
                user.setTanggalLahir(selectedDate);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("extra_user", user);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(this, "Silakan pilih tanggal dulu", Toast.LENGTH_SHORT).show();
            }

        });

        ivBack.setOnClickListener(v -> {
            Intent intent = new Intent(EditTgglLahir.this, ProfilActivity.class);
            intent.putExtra("extra_user", user);
            startActivity(intent);
        });
    }



        private void showDatePicker(){
            final Calendar calendar = Calendar.getInstance();

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    (view, year1, month1, dayOfMonth) -> {
                        // Bulan dimulai dari 0, jadi tambahkan +1
                        selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                        tanggalTextView.setText("Tanggal lahir: " + selectedDate);
                    }, year, month, day);

            datePickerDialog.show();
        };
}