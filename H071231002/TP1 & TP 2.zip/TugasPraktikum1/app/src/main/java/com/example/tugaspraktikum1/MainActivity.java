package com.example.tugaspraktikum1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RelativeLayout relativeLayout;
    ImageView imageView;
    private static User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        relativeLayout = findViewById(R.id.profil);

        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user = new User("Atur Sekarang", "Atur Sekarang", "Atur Sekarang", "Atur Sekarang", "Atur Sekarang", null, 000000);
                Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
                intent.putExtra("extra_user", user);
                startActivity(intent);

            }
        });

        imageView = findViewById(R.id.imgProfilMain);

        Intent intent = getIntent();
        User user = intent.getParcelableExtra("extra_user");
        if (user != null) {
            imageView.setImageURI(user.getImgProfil());
        }












//        Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
//        intent.putExtra("user", user);
//        startActivity(intent);

//        User user = new User("nama", "bio", "jenisKelamin", "tanggalLahir", "email", null, 123456789);
//        Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
//        intent.putExtra("extra_user", user);
//        startActivity(intent);

//        relativeLayout = findViewById(R.id.profil);
//        relativeLayout.setOnClickListener(v -> {
//            User user = new User("nama", "bio", "jenisKelamin", "tanggalLahir", "email", null, 123456789);
//            Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
//            intent.putExtra("extra_user", user);
//            startActivityForResult(intent, 1); // Gunakan startActivityForResult
//        });

//        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        // Ambil URI foto dari SharedPreferences
//        String imageUriString = sharedPreferences.getString("imageUri", null);
//        if (imageUriString != null) {
//            try {
//                Uri imageUri = Uri.parse(imageUriString);
//                imageView.setImageURI(imageUri);
//            } catch (Exception e) {
//                // Tangani kesalahan jika URI tidak valid
//                e.printStackTrace();
//            }
//        }
    }

}