package com.example.tugaspraktikum1;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfilActivity extends AppCompatActivity {


    ImageView imageview;
    LinearLayout linearLayout;
    TextView tvNama, tvBio, tvEmail, tvJk, tvLahir, tvNoHp;;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profil);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        user = getIntent().getParcelableExtra("extra_user");


        tvNama = findViewById(R.id.nama);
        tvBio = findViewById(R.id.bio);
        tvEmail = findViewById(R.id.email);
        tvNoHp = findViewById(R.id.nomor);
        tvJk = findViewById(R.id.jk);
        tvLahir = findViewById(R.id.lahir);

        if (user != null) {
            tvNama.setText(user.getNama());
            tvBio.setText(user.getBio());
            tvEmail.setText(user.getEmail());
            tvNoHp.setText(String.valueOf(user.getNoHandphone()));
            tvJk.setText(user.getJenisKelamin());
            tvLahir.setText(user.getTanggalLahir());
        }


        tvNama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditNama.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });


        tvBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditBio.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });

        tvNoHp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditHp.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });

        tvEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditEmail.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });

        tvJk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditGender.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });

        tvLahir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, EditTgglLahir.class);
                intent.putExtra("extra_user", user);
                startActivityForResult(intent, 2);
            }
        });





        imageview = findViewById(R.id.imgProfil);

        bukaGallery = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.getData() != null) {
                            Uri imageUri = data.getData();
                            imageview.setImageURI(imageUri);

                            user.setImgProfil(imageUri);
                        }
                    }
                }
        );

        imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentGallery = new Intent(Intent.ACTION_PICK);
                intentGallery.setType("image/*");
                bukaGallery.launch(Intent.createChooser(intentGallery, "Pilih Gambar"));
            }
        });



        linearLayout = findViewById(R.id.kembaliMain);

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfilActivity.this, MainActivity.class);
                intent.putExtra("extra_user", user);
                setResult(RESULT_OK, intent);
                startActivity(intent);
            }
        });
    }

    ActivityResultLauncher<Intent> bukaGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if (o.getResultCode() == Activity.RESULT_OK) {
                        Intent data = o.getData();
                        imageview.setImageURI(data.getData());
                    }
                }
            }
    );

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK) {
            user = data.getParcelableExtra("extra_user");
            tvNama.setText(user.getNama());
            tvBio.setText(user.getBio());
            tvEmail.setText(user.getEmail());
            tvNoHp.setText(String.valueOf(user.getNoHandphone()));
            tvJk.setText(user.getJenisKelamin());
            tvLahir.setText(user.getTanggalLahir());

            // Kirim kembali ke MainActivity jika perlu
            Intent returnIntent = new Intent();
            returnIntent.putExtra("extra_user", user);
            setResult(RESULT_OK, returnIntent);
        }
    }

}







//imageview.setOnClickListener(v -> {
//            Intent intentGallery = new Intent(Intent.ACTION_PICK);
//            intentGallery.setType("image/*");
//            bukaGallery.launch(Intent.createChooser(intentGallery, "Pilih Gambar"));
//        });
//        bukaGallery = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                new ActivityResultCallback<ActivityResult>() {
//                    @Override
//                    public void onActivityResult(ActivityResult o) {
//                        if (o.getResultCode() == Activity.RESULT_OK) {
//                            Intent data = o.getData();
//                            if (data != null && data.getData() != null) {
//                                Uri imageUri = data.getData();
//                                imageview.setImageURI(imageUri);
//                                SharedPreferences.Editor editor = sharedPreferences.edit();
//                                editor.putString("imageUri", imageUri.toString());
//                                editor.apply();
//                            }
//                        }
//                    }
//                }
//        );