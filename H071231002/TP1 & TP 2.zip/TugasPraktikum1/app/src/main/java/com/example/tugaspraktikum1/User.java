package com.example.tugaspraktikum1;

import android.adservices.ondevicepersonalization.UserData;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {
    private String nama;
    private String bio;
    private String jenisKelamin;
    private String tanggalLahir;
    private String email;
    private Uri imgProfil;
    private int noHandphone;

    public User(String nama, String bio, String jenisKelamin, String tanggalLahir, String email, Uri imgProfil, int noHandphone) {
        this.nama = nama;
        this.bio = bio;
        this.jenisKelamin = jenisKelamin;
        this.tanggalLahir = tanggalLahir;
        this.email = email;
        this.imgProfil = imgProfil;
        this.noHandphone = noHandphone;
    }

    protected User(Parcel in) {
        nama = in.readString();
        bio = in.readString();
        jenisKelamin = in.readString();
        tanggalLahir = in.readString();
        email = in.readString();
        imgProfil = in.readParcelable(Uri.class.getClassLoader());
        noHandphone = in.readInt();
    }

    public static final Parcelable.Creator<User> CREATOR = new Parcelable.Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nama);
        dest.writeString(bio);
        dest.writeString(jenisKelamin);
        dest.writeString(tanggalLahir);
        dest.writeString(email);
        dest.writeParcelable(imgProfil, flags);
        dest.writeInt(noHandphone);
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public void setJenisKelamin(String jenisKelamin) {
        this.jenisKelamin = jenisKelamin;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = tanggalLahir;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Uri getImgProfil() {
        return imgProfil;
    }

    public void setImgProfil(Uri imgProfil) {
        this.imgProfil = imgProfil;
    }

    public int getNoHandphone() {
        return noHandphone;
    }

    public void setNoHandphone(int noHandphone) {
        this.noHandphone = noHandphone;
    }
}
