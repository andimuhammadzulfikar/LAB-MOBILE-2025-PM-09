package com.example.tp3;

import android.content.Context;
import android.net.Uri;

import java.util.ArrayList;

public class DataSource {
    private static Context context;

    public static ArrayList<Feed> feedList;
    public static ArrayList<Feed> generateFeed(Context context) {
        if (feedList != null) {
            return feedList;
        }


        Feed pertama = new Feed(uriFromDrawable(context, R.drawable.feed1), "Tertangkap lensa bukan sekadar gambar \ntapi cerita yang tak selalu bisa diucap kata.", 1540, 50);
        Feed kedua = new Feed(uriFromDrawable(context, R.drawable.feed4), "Feed 2", 6780, 20);
        Feed ketiga = new Feed(uriFromDrawable(context, R.drawable.feed3), "Berhenti sejenak bukan berarti menyerah,\nhanya ingin menikmati detik tanpa terburu-buru", 1690, 110);
        Feed keempat = new Feed(uriFromDrawable(context, R.drawable.feed2), "Langit sore menyimpan rindu yang tak sempat dikirim, \nterbawa angin pulang bersama cahaya yang perlahan redup.", 1122, 59);
        Feed kelima = new Feed(uriFromDrawable(context, R.drawable.feed5), "Feed 5", 4734, 120);
        Feed keenam = new Feed(uriFromDrawable(context, R.drawable.feed6), "Feed 6", 4590, 40);

        ArrayList<Feed> list = new ArrayList<>();
        list.add(pertama);
        list.add(kedua);
        list.add(ketiga);
        list.add(keempat);
        list.add(kelima);
        list.add(keenam);
        return list;
    }


    private static Uri uriFromDrawable(Context context, int resId) {
        return Uri.parse("android.resource://" + context.getPackageName() + "/" + resId);
    }



    public static ArrayList<Postingan> postinganList = generatePosts();
    public static ArrayList<Postingan> generatePosts() {
        Postingan pertama = new Postingan(R.drawable.profil1, "gnfi", R.drawable.gnfi, 1540, 50, "Pemerintah mempercepat penyusunan regulasi pembangunan Pembangkit Listrik Tenaga Nuklir (PLTN) sebagai bagian dari agenda utama Sidang Perdana Dewan Energi Nasional (DEN) yang dipimpin Menteri ESDM Bahlil Lahadalia pada 17 April 2025. Dalam sidang tersebut, Bahlil menegaskan bahwa pembangunan PLTN masuk dalam RUPTL 2025–2034 dan ditargetkan mulai beroperasi pada 2030 atau 2032. Oleh karena itu, seluruh perangkat regulasi harus segera disiapkan agar pembangunan berjalan tepat waktu dan sesuai standar keamanan.", 1456, 301, 1, "Good News From Indonesia \n\n\nMedia/news company \nOfficial Account Good News From Indonesia \nBusiness inquiries: gnfi@goodnews.id \nwww.goodnewsfromindonesia.id");
        Postingan kedua = new Postingan(R.drawable.profil2, "folkative", R.drawable.folkativ, 6780, 20, "There will be a long weekend every two weeks from April to June 2025. Ready to plan your next short getaway? \n \n [Photo: @pakindro]", 5460, 161, 1, "FOLKATIVE™ \n \n Community \n A one doorway to explore Indonesia’s creative culture.\nTEST KEPRIBADIAN LO DISINI");
        Postingan ketiga = new Postingan(R.drawable.profil3, "prespektiv.idn", R.drawable.prespektif, 1690, 110, "Lorem Ipsum lagi aja, heran deh suka banget buang-buang anggaran untuk sesuatu yang seharusnya dipikirkan secara matang dari awal.\n" + "\n" + "_________________________________\n" +
                "#Perspektiv #Perspektif #BagiPerspektif #BerbagiPerspektif #Jabatan #Pemerintah #Rakyat #Politik #PartaiPolitik #Kabinet #MerahPutih #WakilPresiden #Presiden #IndonesiaGelap #IKN #IbuKotaNusantara #IbuKota #Nusantara #LoremIpsum #Typo #Pejabat #Anggaran", 3854, 364, 1, "Perspektiv \n \n" + "Media\n \n" + "Membaca politik dengan asyik.\n \n" + "Mari #BerbagiPerspektif");
        Postingan keempat = new Postingan(R.drawable.profil4, "puspresnas", R.drawable.puspresnas, 1122, 59, "caption4", 3520, 263, 1, "Ini Bio Profil 4");
        Postingan kelima = new Postingan(R.drawable.profil5, "ussfeeds", R.drawable.ussfeeds, 4734, 120, "caption5", 6875, 686, 1, "Ini Bio Profil 5");
        Postingan keenam = new Postingan(R.drawable.profil6, "klikdokter", R.drawable.klikdokter, 4590, 40, "caption6", 3452, 353, 1, "Ini Bio Profil 6");
        Postingan ketujuh = new Postingan(R.drawable.profil7, "mukaikhlas_", R.drawable.mukaikhlas, 1770, 50, "caption7", 7656, 767, 1, "Ini Bio Profil 7");
        Postingan kedelapan = new Postingan(R.drawable.profil8, "kumparancom", R.drawable.kumparan, 6709, 52, "caption8", 5754, 157, 1, "Ini Bio Profil 8");
        Postingan kesembilan = new Postingan(R.drawable.profil9, "catatanfilm", R.drawable.catatanfilm, 1706, 111, "caption9", 3757, 141, 1, "Ini Bio Profil 9");
        Postingan kesepuluh = new Postingan(R.drawable.profil10, "komersial.beract", R.drawable.komersial, 6576, 35, "caption10", 4684, 341, 1, "Ini Bio Profil 10");


        ArrayList<Postingan> list = new ArrayList<>();
        list.add(pertama);
        list.add(kedua);
        list.add(ketiga);
        list.add(keempat);
        list.add(kelima);
        list.add(keenam);
        list.add(ketujuh);
        list.add(kedelapan);
        list.add(kesembilan);
        list.add(kesepuluh);
        return list;
    }


    public static ArrayList<Sorotan> sorotanList = generateSorotan();
    public static ArrayList<Sorotan> generateSorotan() {
        Sorotan pertama = new Sorotan("Skÿ ", R.drawable.sorotan1, "20 November 2024");
        Sorotan kedua = new Sorotan("⌂", R.drawable.sorotan2, "12 Desember 2024");
        Sorotan ketiga = new Sorotan("/", R.drawable.sorotan3, "13 Januari 2025");
        Sorotan keempat = new Sorotan("☾", R.drawable.sorotan4, "8 Februari 2025");
        Sorotan kelima = new Sorotan("☁", R.drawable.sorotan5, "28 Februari 2025");
        Sorotan keenam = new Sorotan("⟡", R.drawable.sorotan6, "2 Maret 2025");
        Sorotan ketujuh = new Sorotan("blue", R.drawable.sorotan7, "20 Maret 2025");
        Sorotan kedelapan = new Sorotan("line", R.drawable.sorotan8, "12 April 2025");
        Sorotan kesembilan = new Sorotan("^^", R.drawable.sorotan9, "24 April 2025");

        ArrayList<Sorotan> list = new ArrayList<>();
        list.add(pertama);
        list.add(kedua);
        list.add(ketiga);
        list.add(keempat);
        list.add(kelima);
        list.add(keenam);
        list.add(ketujuh);
        list.add(kedelapan);
        list.add(kesembilan);
        return list;
    }





}

