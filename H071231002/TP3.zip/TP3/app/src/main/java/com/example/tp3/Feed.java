package com.example.tp3;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Feed implements Parcelable {
    private Uri gambarFeed;
    private String caption;
    private int likes;
    private int comments;

    public Feed(Uri gambarFeed, String caption, int likes, int comments) {
        this.gambarFeed = gambarFeed;
        this.caption = caption;
        this.likes = likes;
        this.comments = comments;
    }

    protected Feed(Parcel in) {
        gambarFeed = in.readParcelable(Uri.class.getClassLoader());
        caption = in.readString();
        likes = in.readInt();
        comments = in.readInt();
    }

    public static final Creator<Feed> CREATOR = new Parcelable.Creator<Feed>() {
        @Override
        public Feed createFromParcel(Parcel in) {
            return new Feed(in);
        }

        @Override
        public Feed[] newArray(int size) {
            return new Feed[size];
        }
    };

    public Uri getGambarFeed() {
        return gambarFeed;
    }

    public void setGambarFeed(Uri gambarFeed) {
        this.gambarFeed = gambarFeed;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getComments() {
        return comments;
    }

    public void setComments(int comments) {
        this.comments = comments;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int flags) {
        parcel.writeParcelable(gambarFeed, flags);
        parcel.writeString(caption);
        parcel.writeInt(likes);
        parcel.writeInt(comments);
    }
}
