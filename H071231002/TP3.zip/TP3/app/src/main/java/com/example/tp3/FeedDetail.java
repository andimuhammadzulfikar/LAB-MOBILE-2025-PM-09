package com.example.tp3;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FeedDetail extends AppCompatActivity {
    Feed feed;
    ImageView detail_feed_gambar;
    TextView detail_feed_like;
    TextView detail_feed_komen;
    TextView detail_feed_caption;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_feed_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        feed = getIntent().getParcelableExtra("feed");

        detail_feed_gambar = findViewById(R.id.detail_feed_gambar);
        detail_feed_like = findViewById(R.id.detail_feed_like);
        detail_feed_komen = findViewById(R.id.detail_feed_komen);
        detail_feed_caption = findViewById(R.id.detail_feed_caption);

        if (feed != null && feed.getGambarFeed() != null) {
            detail_feed_gambar.setImageURI(feed.getGambarFeed());
            detail_feed_like.setText(String.valueOf(feed.getLikes()));
            detail_feed_komen.setText(String.valueOf(feed.getComments()));
            detail_feed_caption.setText("an_zulfik_  " + feed.getCaption());

            detail_feed_caption.setOnClickListener(new View.OnClickListener() {
                boolean expanded = false;

                public void onClick(View v) {
                    if (expanded) {
                        detail_feed_caption.setMaxLines(1);
                        detail_feed_caption.setEllipsize(TextUtils.TruncateAt.END);
                    } else {
                        detail_feed_caption.setMaxLines(Integer.MAX_VALUE);
                        detail_feed_caption.setEllipsize(null);
                    }
                    expanded = !expanded;
                }
            });
        } else {
            Toast.makeText(this, "Error loading feed", Toast.LENGTH_SHORT).show();
            finish();
        }

    }
}







//if (feed != null) {
//            detail_feed_gambar.setImageURI(feed.getGambarFeed());
//            detail_feed_like.setText(String.valueOf(feed.getLikes()));
//            detail_feed_komen.setText(String.valueOf(feed.getComments()));
//            detail_feed_caption.setText(feed.getCaption());
//        }