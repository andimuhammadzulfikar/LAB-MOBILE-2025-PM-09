package com.example.tp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvPostingan;
    private ImageView navProfil, navPosting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        DataSource.postinganList = DataSource.generatePosts();

        rvPostingan = findViewById(R.id.rv_ig);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        rvPostingan.setLayoutManager(linearLayoutManager);

        PostinganAdapter adapter = new PostinganAdapter(this, DataSource.postinganList);
        rvPostingan.setAdapter(adapter);


        navProfil = findViewById(R.id.nav_profil);
        navProfil.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MainProfile.class);
            startActivity(intent);
        });

        navPosting = findViewById(R.id.nav_posting);
        navPosting.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, MainPosting.class);
            startActivity(intent);
        });



    }
}