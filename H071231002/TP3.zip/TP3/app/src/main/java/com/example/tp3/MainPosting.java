package com.example.tp3;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class MainPosting extends AppCompatActivity {
    private ImageView navBeranda, navProfil, uploadGambar;
    private EditText uploadCaption;
    private MaterialButton uploadButton;
    Uri gambarFeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_posting);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        navBeranda = findViewById(R.id.nav_beranda);
        navBeranda.setOnClickListener(v -> {
            Intent intent = new Intent(MainPosting.this, MainActivity.class);
            startActivity(intent);
        });
        navProfil = findViewById(R.id.nav_profil);
        navProfil.setOnClickListener(v -> {
            Intent intent = new Intent(MainPosting.this, MainProfile.class);
            startActivity(intent);
        });




        uploadGambar = findViewById(R.id.upload_gambar);

        bukaGallery = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.getData() != null) {
                            Uri uri = data.getData();

                            final int takeFlags = data.getFlags()
                                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                            getContentResolver().takePersistableUriPermission(uri, takeFlags);

                            gambarFeed = uri;
                            uploadGambar.setImageURI(uri);
                        }
                    }
                }
        );


        uploadGambar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentGallery = new Intent(Intent.ACTION_PICK);
                intentGallery.setType("image/*");
                bukaGallery.launch(Intent.createChooser(intentGallery, "Pilih Gambar"));
            }
        });


        uploadCaption = findViewById(R.id.upload_caption);
        uploadButton = findViewById(R.id.upload_button);

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String caption = uploadCaption.getText().toString();


                if (caption.isEmpty()) {
                    Toast.makeText(MainPosting.this, "Masukkan Caption Anda", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (gambarFeed == null) {
                    Toast.makeText(MainPosting.this, "Gambar Postingan Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (DataSource.feedList == null) {
                    DataSource.feedList = new ArrayList<>();
                }

                Feed newFeed = new Feed(gambarFeed, caption, 0, 0);
                DataSource.feedList.add(0, newFeed);

                Toast.makeText(MainPosting.this, "Postingan Berhasil Ditambahkan", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainPosting.this, MainProfile.class);
                intent.putExtra("feed", newFeed);
                startActivity(intent);
                finish();
            }
        });

    }







    ActivityResultLauncher<Intent> bukaGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if (o.getResultCode() == Activity.RESULT_OK) {
                        Intent data = o.getData();
                        gambarFeed = data.getData();
                        uploadGambar.setImageURI(data.getData());
                    }
                }
            }
    );
}







//        bukaGallery = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                result -> {
//                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        Intent data = result.getData();
//                        if (data != null && data.getData() != null) {
//                            gambarFeed = data.getData();
//                            uploadGambar.setImageURI(gambarFeed);
//                        }
//                    }
//                }
//        );

//        uploadGambar.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
//                intent.addCategory(Intent.CATEGORY_OPENABLE);
//                intent.setType("image/*");
//                bukaGallery.launch(Intent.createChooser(intent, "Pilih Gambar"));
//
//            }
//        });


//    ActivityResultLauncher<Intent> bukaGallery = registerForActivityResult(
//            new ActivityResultContracts.StartActivityForResult(),
//            result -> {
//                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
//                    Uri uri = result.getData().getData();
//                    if (uri != null) {
//                        // Simpan izin untuk digunakan di Activity lain
//                        final int takeFlags = result.getData().getFlags()
//                                & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
//
//                        getContentResolver().takePersistableUriPermission(uri, takeFlags);
//
//                        gambarFeed = uri;
//                        uploadGambar.setImageURI(uri);
//                    }
//                }
//            }
//    );


