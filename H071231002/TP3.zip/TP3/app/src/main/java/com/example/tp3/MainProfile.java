package com.example.tp3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainProfile extends AppCompatActivity {
    private RecyclerView rvSorotan, rvFeed;
    private ImageView navBeranda, navPosting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Feed feed = getIntent().getParcelableExtra("feed");
//        if (feed != null) {
//            DataSource.feedList.add(0, feed);
//        }

        navBeranda = findViewById(R.id.nav_beranda);
        navBeranda.setOnClickListener(v -> {
            Intent intent = new Intent(MainProfile.this, MainActivity.class);
            startActivity(intent);
        });

        navPosting = findViewById(R.id.nav_posting);
        navPosting.setOnClickListener(v -> {
            Intent intent = new Intent(MainProfile.this, MainPosting.class);
            startActivity(intent);
        });



        rvSorotan = findViewById(R.id.rv_sorotan);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        rvSorotan.setLayoutManager(linearLayoutManager);

        SorotanAdapter adapter = new SorotanAdapter(this, DataSource.sorotanList);
        rvSorotan.setAdapter(adapter);


        rvFeed = findViewById(R.id.rv_feed);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 3);
        rvFeed.setLayoutManager(gridLayoutManager);

        if (DataSource.feedList == null) {
            DataSource.feedList = DataSource.generateFeed(this);
        }

        FeedAdapter feedAdapter = new FeedAdapter(this, DataSource.feedList);
        rvFeed.setAdapter(feedAdapter);

    }
}