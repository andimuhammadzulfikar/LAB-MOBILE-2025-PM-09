package com.example.tp3;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Postingan implements Parcelable {
    private int profile;
    private String username;
    private int postingan;
    private int like;
    private int komentar;
    private String caption;
    private int following;
    private int followers;
    private int jumlahpost;
    private String bio;


    public Postingan(int profile, String username, int postingan, int like, int komentar, String caption, int following, int followers, int jumlahpost, String bio) {
        this.profile = profile;
        this.username = username;
        this.postingan = postingan;
        this.like = like;
        this.komentar = komentar;
        this.caption = caption;
        this.following = following;
        this.followers = followers;
        this.jumlahpost = jumlahpost;
        this.bio = bio;
    }

    protected Postingan(Parcel in){
        profile = in.readInt();
        username = in.readString();
        postingan = in.readInt();
        like = in.readInt();
        komentar = in.readInt();
        caption = in.readString();
        following = in.readInt();
        followers = in.readInt();
        jumlahpost = in.readInt();
        bio = in.readString();
    }


    public static final Creator<Postingan> CREATOR = new Parcelable.Creator<Postingan>() {
        @Override
        public Postingan createFromParcel(Parcel in) {
            return new Postingan(in);
        }

        @Override
        public Postingan[] newArray(int size) {
            return new Postingan[size];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(profile);
        dest.writeString(username);
        dest.writeInt(postingan);
        dest.writeInt(like);
        dest.writeInt(komentar);
        dest.writeString(caption);
        dest.writeInt(following);
        dest.writeInt(followers);
        dest.writeInt(jumlahpost);
        dest.writeString(bio);
    }




    public int getProfile() {
        return profile;
    }

    public void setProfile(int profile) {
        this.profile = profile;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPostingan() {
        return postingan;
    }

    public void setPostingan(int postingan) {
        this.postingan = postingan;
    }

    public int getLike() {
        return like;
    }

    public void setLike(int like) {
        this.like = like;
    }

    public int getKomentar() {
        return komentar;
    }

    public void setKomentar(int komentar) {
        this.komentar = komentar;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getFollowing() {
        return following;
    }

    public void setFollowing(int following) {
        this.following = following;
    }

    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public int getJumlahpost() {
        return jumlahpost;
    }

    public void setJumlahpost(int jumlahpost) {
        this.jumlahpost = jumlahpost;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }


}






//package com.example.tp3;
//
//public class Postingan {
//    private int profile;
//    private String username;
//    private int postingan;
//    private int like;
//    private int komentar;
//    private String caption;
//    private int following;
//    private int followers;
//    private int jumlahpost;
//    private String bio;
//
//    public Postingan(int profile, String username, int postingan, int like, int komentar, String caption) {
//        this.profile = profile;
//        this.username = username;
//        this.postingan = postingan;
//        this.like = like;
//        this.komentar = komentar;
//        this.caption = caption;
//    }
//
//
//    public int getProfile() {
//        return profile;
//    }
//
//    public void setProfile(int profile) {
//        this.profile = profile;
//    }
//
//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//    public int getPostingan() {
//        return postingan;
//    }
//
//    public void setPostingan(int postingan) {
//        this.postingan = postingan;
//    }
//
//    public int getLike() {
//        return like;
//    }
//
//    public void setLike(int like) {
//        this.like = like;
//    }
//
//    public int getKomentar() {
//        return komentar;
//    }
//
//    public void setKomentar(int komentar) {
//        this.komentar = komentar;
//    }
//
//    public String getCaption() {
//        return caption;
//    }
//
//    public void setCaption(String caption) {
//        this.caption = caption;
//    }
//}
