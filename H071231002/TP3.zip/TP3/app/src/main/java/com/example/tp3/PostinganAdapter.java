package com.example.tp3;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostinganAdapter extends RecyclerView.Adapter<PostinganAdapter.ViewHolder>{
    private Context context;
    private ArrayList<Postingan> postinganList;

    public PostinganAdapter(Context context, ArrayList<Postingan> postinganList) {
        this.context = context;
        this.postinganList = postinganList;
    }

    @NonNull
    @Override
    public PostinganAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostinganAdapter.ViewHolder holder, int position) {
        Postingan postingan = postinganList.get(position);
        holder.setData(postingan);

        holder.iv_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Profile.class);
                intent.putExtra("postingan", postingan);
                context.startActivity(intent);
            }
        });

        holder.tv_username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, Profile.class);
                intent.putExtra("postingan", postingan);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return postinganList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_profile, iv_postingan;
        private TextView tv_username, tv_username_capt, tv_like, tv_komentar, tv_caption;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            iv_profile = itemView.findViewById(R.id.iv_profile);
            iv_postingan = itemView.findViewById(R.id.iv_postingan);
            tv_username = itemView.findViewById(R.id.tv_username);
            tv_username_capt = itemView.findViewById(R.id.tv_username_capt);
            tv_like = itemView.findViewById(R.id.tv_like);
            tv_komentar = itemView.findViewById(R.id.tv_komentar);
//            tv_caption = itemView.findViewById(R.id.tv_caption);

        }

        public void setData(Postingan postingan) {
            iv_profile.setImageResource(postingan.getProfile());
            iv_postingan.setImageResource(postingan.getPostingan());
            tv_username.setText(postingan.getUsername());
            tv_username_capt.setText(postingan.getUsername() + "  " + postingan.getCaption());
            tv_like.setText(String.valueOf(postingan.getLike()));
            tv_komentar.setText(String.valueOf(postingan.getKomentar()));
//            tv_caption.setText(postingan.getCaption());

            tv_username_capt.setMaxLines(1);
            tv_username_capt.setEllipsize(TextUtils.TruncateAt.END);

            tv_username_capt.setOnClickListener(new View.OnClickListener() {
                boolean expanded = false;

                @Override
                public void onClick(View view) {
                    if (expanded) {
                        tv_username_capt.setMaxLines(1);
                        tv_username_capt.setEllipsize(TextUtils.TruncateAt.END);
                    } else {
                        tv_username_capt.setMaxLines(Integer.MAX_VALUE);
                        tv_username_capt.setEllipsize(null);
                    }
                    expanded = !expanded;
                }
            });
        }
    }
}
