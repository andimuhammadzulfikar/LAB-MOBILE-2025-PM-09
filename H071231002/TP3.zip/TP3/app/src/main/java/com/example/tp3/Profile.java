package com.example.tp3;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Profile extends AppCompatActivity {
    Postingan postingan;
    private TextView profile_username, profile_bio, profile_following, profile_followers, profile_jumlahpost;
    private ImageView profile_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        postingan = getIntent().getParcelableExtra("postingan");

        profile_username = findViewById(R.id.profil_username);
        profile_bio = findViewById(R.id.profil_bio);
        profile_following = findViewById(R.id.profil_following);
        profile_followers = findViewById(R.id.profil_followers);
        profile_jumlahpost = findViewById(R.id.profil_postingan);
        profile_image = findViewById(R.id.profil_fotoprofil);


        if (postingan != null) {
            profile_username.setText(postingan.getUsername());
            profile_bio.setText(postingan.getBio());
            profile_following.setText(String.valueOf(postingan.getFollowing()));
            profile_followers.setText(String.valueOf(postingan.getFollowers()));
            profile_jumlahpost.setText(String.valueOf(postingan.getJumlahpost()));
            profile_image.setImageResource(postingan.getProfile());

            profile_bio.setOnClickListener(new View.OnClickListener() {
                boolean expanded = false;
                public void onClick(View v) {
                    if (expanded) {
                        profile_bio.setMaxLines(5);
                        profile_bio.setEllipsize(TextUtils.TruncateAt.END);
                    } else {
                        profile_bio.setMaxLines(Integer.MAX_VALUE);
                        profile_bio.setEllipsize(null);
                    }
                    expanded = !expanded;
                }
            });
        }
    }
}