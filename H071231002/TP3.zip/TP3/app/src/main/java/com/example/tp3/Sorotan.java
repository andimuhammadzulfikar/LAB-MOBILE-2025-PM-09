package com.example.tp3;


import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Sorotan implements Parcelable {
    private String judul;
    private int gambarsorotan;
    private String tanggal;


    public Sorotan(String judul, int gambarsorotan, String tanggal) {
        this.judul = judul;
        this.gambarsorotan = gambarsorotan;
        this.tanggal = tanggal;
    }

    protected Sorotan(Parcel in) {
        judul = in.readString();
        gambarsorotan = in.readInt();
        tanggal = in.readString();
    }

    public static final Creator<Sorotan> CREATOR = new Parcelable.Creator<Sorotan>() {
        @Override
        public Sorotan createFromParcel(Parcel in) {
            return new Sorotan(in);
        }

        @Override
        public Sorotan[] newArray(int size) {
            return new Sorotan[size];
        }
    };

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public int getGambarsorotan() {
        return gambarsorotan;
    }

    public void setGambarsorotan(int gambarsorotan) {
        this.gambarsorotan = gambarsorotan;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }




    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int flags) {
        parcel.writeString(judul);
        parcel.writeInt(gambarsorotan);
        parcel.writeString(tanggal);
    }
}
