package com.example.tp3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SorotanAdapter extends RecyclerView.Adapter<SorotanAdapter.ViewHolder> {
    private ArrayList<Sorotan> sorotanList;
    private Context context;


    public SorotanAdapter(Context context, ArrayList<Sorotan> sorotanList) {
        this.context = context;
        this.sorotanList = sorotanList;
    }

    @NonNull
    @Override
    public SorotanAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sorotan, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SorotanAdapter.ViewHolder holder, int position) {
        Sorotan sorotan = sorotanList.get(position);
        holder.setData(sorotan);

        holder.gambar_sorotan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, SorotanDetail.class);
                intent.putExtra("sorotan", sorotan);
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return sorotanList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView gambar_sorotan;
        private TextView judul_sorotan;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            gambar_sorotan = itemView.findViewById(R.id.sorotan_gambar);
            judul_sorotan = itemView.findViewById(R.id.sorotan_judul);
        }

        public void setData(Sorotan sorotan) {
            gambar_sorotan.setImageResource(sorotan.getGambarsorotan());
            judul_sorotan.setText(sorotan.getJudul());
        }
    }
}
