package com.example.tp4;

import static android.app.Activity.RESULT_OK;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;


public class AddBookFragment extends Fragment {
    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivUpload;
    private EditText etJudul, etPenulis, etTahun, etGenre, etSinopsis;
    private MaterialButton btnSimpan;
    private Uri selectedImageUri;

    private LinearLayout layoutGenre;
    private Button btnGenre;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_book, container, false);

        ivUpload = view.findViewById(R.id.upload_gambar);
        etJudul = view.findViewById(R.id.et_judul);
        etPenulis = view.findViewById(R.id.et_penulis);
        etTahun = view.findViewById(R.id.et_tahun);
        etGenre = view.findViewById(R.id.et_genre);
        etSinopsis = view.findViewById(R.id.et_sinopsis);
        btnSimpan = view.findViewById(R.id.btn_simpan);

        ivUpload.setOnClickListener(v -> openGallery());

        btnSimpan.setOnClickListener(v -> {
            String judul = etJudul.getText().toString();
            String penulis = etPenulis.getText().toString();
            String tahunText = etTahun.getText().toString();
            String genre = etGenre.getText().toString();
            String sinopsis = etSinopsis.getText().toString();

            if (selectedImageUri != null && !judul.isEmpty() && !penulis.isEmpty() &&
                    !genre.isEmpty() && !sinopsis.isEmpty() && !tahunText.isEmpty()) {
                try {
                    int tahun = Integer.parseInt(tahunText);
                    if (tahun > 0) {
                        Books newBook = new Books(selectedImageUri, judul, penulis, tahun, sinopsis, false , genre);
//                        DataSource.addBook(newBook);
                        DataSource.booksList.add(0, newBook);

                        Toast.makeText(getContext(), "Buku berhasil ditambahkan", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Tahun harus lebih dari 0", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(getContext(), "Tahun tidak valid", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Mohon lengkapi semua data", Toast.LENGTH_SHORT).show();
            }


        });

        btnGenre = view.findViewById(R.id.btn_pilih_genre);

        btnGenre.setOnClickListener(view1 -> showSheetGenre());



        return view;
    }

    private void showSheetGenre() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireContext());
        View sheetView = LayoutInflater.from(getContext()).inflate(R.layout.sheet_genre, null);
        bottomSheetDialog.setContentView(sheetView);

        RadioGroup rgGenre = sheetView.findViewById(R.id.rg_genre);

        rgGenre.setOnCheckedChangeListener((group, checkedId) -> {
            String selectedGenre = "";

            if (checkedId == R.id.rb_fiksi) {
                selectedGenre = "Fiksi";
            } else if (checkedId == R.id.rb_nonfiksi) {
                selectedGenre = "Non-Fiksi";
            } else if (checkedId == R.id.rb_biografi) {
                selectedGenre = "Biografi";
            } else if (checkedId == R.id.rb_novel) {
                selectedGenre = "Novel";
            } else if (checkedId == R.id.rb_cerpen) {
                selectedGenre = "Cerpen";
            } else if (checkedId == R.id.rb_politik) {
                selectedGenre = "Politik";
            } else if (checkedId == R.id.rb_komik) {
                selectedGenre = "Komik";
            } else if (checkedId == R.id.rb_fantasi) {
                selectedGenre = "Fantasi";
            } else if (checkedId == R.id.rb_horor) {
                selectedGenre = "Horror";
            } else if (checkedId == R.id.rb_romansa) {
                selectedGenre = "Romansa";
            } else if (checkedId == R.id.rb_misteri) {
                selectedGenre = "Misteri";
            } else if (checkedId == R.id.rb_sejarah) {
                selectedGenre = "Sejarah";
            } else if (checkedId == R.id.rb_sains) {
                selectedGenre = "Sains";
            }

            etGenre.setText(selectedGenre);
            bottomSheetDialog.dismiss();
        });

        bottomSheetDialog.show();
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            ivUpload.setImageURI(selectedImageUri);
        }
    }


}









//
//        bukaGallery = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                result -> {
//                    if (result.getResultCode() == Activity.RESULT_OK) {
//                        Intent data = result.getData();
//                        if (data != null && data.getData() != null) {
//                            Uri uri = data.getData();
//
//                            final int takeFlags = data.getFlags()
//                                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
//
//                            getContentResolver().takePersistableUriPermission(uri, takeFlags);
//
//                            gambarFeed = uri;
//                            ivUpload.setImageURI(uri);
//                        }
//                    }
//                }
//        );
//
//
//        ivUpload.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intentGallery = new Intent(Intent.ACTION_PICK);
//                intentGallery.setType("image/*");
//                bukaGallery.launch(Intent.createChooser(intentGallery, "Pilih Gambar"));
//            }
//        });










//    ActivityResultLauncher<Intent> bukaGallery = registerForActivityResult(
//            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
//                @Override
//                public void onActivityResult(ActivityResult o) {
//                    if (o.getResultCode() == Activity.RESULT_OK) {
//                        Intent data = o.getData();
//                        gambarFeed = data.getData();
//                        ivUpload.setImageURI(data.getData());
//                    }
//                }
//            }
//    );