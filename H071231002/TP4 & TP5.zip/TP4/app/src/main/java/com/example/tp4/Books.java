package com.example.tp4;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;



public class Books implements Parcelable{
    private Uri sampul;
    private String judul;
    private String penulis;
    private int tahun;
    private String sinopsis;
    private boolean disukai;
    private String genre;


    public Books(Uri sampul, String judul, String penulis, int tahun, String sinopsis, boolean disukai, String genre) {
        this.sampul = sampul;
        this.judul = judul;
        this.penulis = penulis;
        this.tahun = tahun;
        this.sinopsis = sinopsis;
        this.disukai = disukai;
        this.genre = genre;
    }

    protected Books(Parcel in) {
        sampul = in.readParcelable(Uri.class.getClassLoader());
        judul = in.readString();
        penulis = in.readString();
        tahun = in.readInt();
        sinopsis = in.readString();
        disukai = in.readByte() != 0;
        genre = in.readString();
    }

    public static final Creator<Books> CREATOR = new Creator<Books>() {
        @Override
        public Books createFromParcel(Parcel in) {
            return new Books(in);
        }

        @Override
        public Books[] newArray(int size) {
            return new Books[size];
        }
    };

    public Uri getSampul() {
        return sampul;
    }

    public void setSampul(Uri sampul) {
        this.sampul = sampul;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getPenulis() {
        return penulis;
    }

    public void setPenulis(String penulis) {
        this.penulis = penulis;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public boolean isDisukai() {
        return disukai;
    }

    public void setDisukai(boolean disukai) {
        this.disukai = disukai;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeParcelable(sampul, i);
        parcel.writeString(judul);
        parcel.writeString(penulis);
        parcel.writeInt(tahun);
        parcel.writeString(sinopsis);
        parcel.writeByte((byte) (disukai ? 1 : 0));
        parcel.writeString(genre);
    }
}
