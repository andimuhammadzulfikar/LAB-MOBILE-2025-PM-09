package com.example.tp4;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BooksAdapter extends RecyclerView.Adapter<BooksAdapter.ViewHolder> {
    private static ArrayList<Books> booksList;
    private Context context;

    public BooksAdapter(Context context, ArrayList<Books> booksList) {
        this.context = context;
        this.booksList = booksList;
    }

    @NonNull
    @Override
    public BooksAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.books, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BooksAdapter.ViewHolder holder, int position) {
        Books books = booksList.get(position);
        holder.setData(books);

    }

    @Override
    public int getItemCount() {
        return booksList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivSampul;
        private TextView tvJudul, tvPenulis, tvTahun;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            ivSampul = itemView.findViewById(R.id.iv_sampul);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvPenulis = itemView.findViewById(R.id.tv_penulis);
            tvTahun = itemView.findViewById(R.id.tv_tahun);

            itemView.setOnClickListener(view -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Intent intent = new Intent(context, DetailBooks.class);
                    intent.putExtra("book_index", position);
                    context.startActivity(intent);
                }
            });
        }

        public void setData(Books books) {
            ivSampul.setImageURI(books.getSampul());
            tvJudul.setText(books.getJudul());
            tvPenulis.setText(books.getPenulis());
            tvTahun.setText(String.valueOf(books.getTahun()));
        }
    }

    public void updateData(ArrayList<Books> newList) {
        booksList = newList;
        notifyDataSetChanged();
    }
}




//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(context, DetailBooks.class);
//                intent.putExtra("book_index", getAdapterPosition());
////                intent.putExtra("books", books);
//                context.startActivity(intent);
//            }
//        });