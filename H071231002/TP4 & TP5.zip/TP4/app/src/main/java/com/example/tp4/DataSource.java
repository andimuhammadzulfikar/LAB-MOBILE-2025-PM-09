package com.example.tp4;

import android.content.Context;
import android.net.Uri;

import java.util.ArrayList;

public class DataSource {
    private Context context;

    static ArrayList<Books> booksList;
    public static ArrayList<Books> generateBooks(Context context) {
        if (booksList != null) {
            return booksList;
        }

        Books pertama = new Books(uriFromDrawable(context, R.drawable.laskarpelangi), "Laskar Pelangi", "Andrea Hirata", 2005, "Mengisahkan perjuangan 10 anak dari keluarga miskin di Belitung yang bersekolah di SD Muhammadiyah. Kisah mereka penuh semangat, harapan, dan persahabatan.", false, "Cerpen");
        Books kedua = new Books(uriFromDrawable(context, R.drawable.badaiberlalu), "Badai Pasti Berlalu", "Marga T", 1974, "Novel ini berkisah tentang Siska, seorang wanita yang patah hati karena tunangannya membatalkan pernikahan mereka dan menikahi sahabatnya. Dalam upaya menyembuhkan luka hatinya, Siska bertemu dengan Leo, seorang playboy yang awalnya mendekatinya karena taruhan, namun akhirnya benar-benar jatuh cinta padanya. Konflik semakin rumit dengan kehadiran Helmi, seorang pianis klub malam yang memaksa Siska menikah dengannya dengan ancaman mengungkap rahasia keluarganya.", false, "Romansa");
        Books ketiga = new Books(uriFromDrawable(context, R.drawable.bumimanusia), "Bumi Manusia", "Pramoedya Ananta Toer", 1980, "Kisah Minke, seorang pemuda pribumi berdarah bangsawan yang menempuh pendidikan di sekolah Belanda pada masa kolonial. Novel ini menggambarkan perjuangan Minke dalam menghadapi diskriminasi rasial dan sosial, serta pencarian identitas nasional.", false, "Politik");
        Books keempat = new Books(uriFromDrawable(context, R.drawable.saman), "Saman", "Ayu Utami", 1998, "Mengisahkan kehidupan empat perempuan dan seorang mantan pastor bernama Saman yang menjadi aktivis hak asasi manusia. Novel ini mengeksplorasi tema seksualitas, agama, dan politik pada masa Orde Baru.", false, "Politik");
        Books kelima = new Books(uriFromDrawable(context, R.drawable.lautbercerita), "Laut Bercerita", "Leila S. Chudori", 2017, "Bercerita tentang Biru Laut, seorang aktivis yang diculik dan hilang pada masa Orde Baru. Novel ini menggambarkan penderitaan keluarga korban penculikan dan perjuangan mereka mencari keadilan.", false, "Politik");
        Books keenam = new Books(uriFromDrawable(context, R.drawable.amba), "Amba", "Laksmi Pamuntjak", 2012, "Mengisahkan perjalanan hidup Amba yang terjalin dengan latar sejarah kelam G30S dan kamp konsentrasi di Pulau Buru. Kisah cinta dan pencarian jati diri menjadi inti dari novel ini.", false, "Sejarah");
        Books ketujuh = new Books(uriFromDrawable(context, R.drawable.perahu_kertas), "Perahu Kertas", "Dewi Lestari", 2009, "Kugy dan Keenan, dua jiwa kreatif, saling jatuh cinta dalam perjalanan hidup mereka. Namun takdir terus mempermainkan hubungan mereka hingga mereka menemukan jati diri masing-masing.", false, "Romansa");
        Books kedelapan = new Books(uriFromDrawable(context, R.drawable.supernova), "Supernova: Ksatria, Puteri, dan Bintang Jatuh", "Dewi Lestari", 2001, "Dua mahasiswa membangun dunia fiksi dengan tokoh-tokoh yang mencerminkan realitas hidup modern dan pencarian spiritual. Fiksi ilmiah, filsafat, dan psikologi berpadu dalam karya ini.", false, "Fiksi");
        Books kesembilan  = new Books(uriFromDrawable(context, R.drawable.negeri_5_menara), "Negeri 5 Menara", "Ahmad Fuadi", 2009, "Perjalanan enam santri di pesantren yang memiliki mimpi besar, dikisahkan dengan semangat motivasional dan nilai-nilai pendidikan Islam.", false, "Inspiratif");

        booksList = new ArrayList<>();
        booksList.add(pertama);
        booksList.add(kedua);
        booksList.add(ketiga);
        booksList.add(keempat);
        booksList.add(kelima);
        booksList.add(keenam);
        booksList.add(ketujuh);
        booksList.add(kedelapan);
        booksList.add(kesembilan);
        return booksList;


    }

    public static void addBook(Books book) {
        if (booksList != null) {
            booksList.add(book);
        }
    }

    private static Uri uriFromDrawable(Context context, int resId) {
        return Uri.parse("android.resource://" + context.getPackageName() + "/" + resId);
    }


}
