package com.example.tp4;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;

public class DetailBooks extends AppCompatActivity {
    Books books;
    ImageView ivCover;
    TextView tvJudul, tvPenulis, tvTahun, tvGenre, tvSinopsis;
    MaterialButton btnFav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail_books);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        books = getIntent().getParcelableExtra("books");

        if (books == null) {
            int index = getIntent().getIntExtra("book_index", -1);
            if (index != -1) {
                books = DataSource.generateBooks(this).get(index);
            } else {
                Toast.makeText(this, "Error loading book detail", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }

        ivCover = findViewById(R.id.iv_cover);
        tvJudul = findViewById(R.id.tv_judul);
        tvPenulis = findViewById(R.id.tv_penulis);
        tvTahun = findViewById(R.id.tv_tahun);
        tvGenre = findViewById(R.id.tv_genre);
        tvSinopsis = findViewById(R.id.tv_sinopsis);

        if (books != null) {
            ivCover.setImageURI(books.getSampul());
            tvJudul.setText(books.getJudul());
            tvPenulis.setText(books.getPenulis());
            tvTahun.setText(String.valueOf(books.getTahun()));
            tvGenre.setText(books.getGenre());
            tvSinopsis.setText(books.getSinopsis());
        } else {
            Toast.makeText(this, "Error loading feed", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnFav = findViewById(R.id.btn_fav);


        btnFav.setOnClickListener(view -> {
            books.setDisukai(!books.isDisukai());

            if (books.isDisukai()) {
                Toast.makeText(this, "Berhasil Menambahkan ke Favorit", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Berhasil Menghapus dari Favorit", Toast.LENGTH_SHORT).show();
            }

            updateLikeButton();
        });

        updateLikeButton();
    }

    private void updateLikeButton() {
        if (books.isDisukai()) {
            btnFav.setText("Hapus dari Favorit");
        } else {
            btnFav.setText("Tambahkan ke Favorit");
        }
    }

}



//        books = getIntent().getParcelableExtra("books");
//
//        int index = getIntent().getIntExtra("book_index", -1);
//        if (index != -1) {
//            books = DataSource.generateBooks(this).get(index);
//        } else {
//            Toast.makeText(this, "Error loading book detail", Toast.LENGTH_SHORT).show();
//            finish();
//        }
