package com.example.tp4;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FavBookFragment extends Fragment {
    private RecyclerView rvFav;
    private ArrayList<Books> favBooksList = new ArrayList<>();
    private FavoriteAdapter favoriteAdapter;
    private TextView tvKosongFav;
    private ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fav_book, container, false);

        rvFav = view.findViewById(R.id.rv_fav);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false);
        rvFav.setLayoutManager(linearLayoutManager);

        favoriteAdapter = new FavoriteAdapter(requireContext(), favBooksList);
        rvFav.setAdapter(favoriteAdapter);

        tvKosongFav = view.findViewById(R.id.tv_empty_fav);
        progressBar = view.findViewById(R.id.progressBar_fav);



        loadFavorites();

        return view;

    }

    ExecutorService executor = Executors.newSingleThreadExecutor();
    Handler handler = new Handler(Looper.getMainLooper());

    private void loadFavorites() {
        showLoading(true);

        executor.execute(() -> {
            ArrayList<Books> tempList = new ArrayList<>();
            for (Books book : DataSource.generateBooks(requireContext())) {
                if (book.isDisukai()) {
                    tempList.add(book);
                }
            }

            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            handler.post(() -> {
                favBooksList.clear();
                favBooksList.addAll(tempList);
                favoriteAdapter.notifyDataSetChanged();

                tvKosongFav.setVisibility(favBooksList.isEmpty() ? View.VISIBLE : View.GONE);
                showLoading(false);
            });
        });
    }


    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        rvFav.setVisibility(isLoading ? View.GONE : View.VISIBLE);
    }


    @Override
    public void onResume() {
        super.onResume();
        loadFavorites();
    }

}

//    private void loadFavorites() {
//        favBooksList.clear();
//        for (Books book : DataSource.generateBooks(requireContext())) {
//            if (book.isDisukai()) {
//                favBooksList.add(book);
//            }
//        }
//        favoriteAdapter.notifyDataSetChanged();
//
//        if (favBooksList.isEmpty()) {
//            tvKosongFav.setVisibility(View.VISIBLE);
//        } else {
//            tvKosongFav.setVisibility(View.GONE);
//        }
//    }









//        favBooksList = new ArrayList<>();
//        for (Books book : DataSource.generateBooks(requireContext())) {
//            if (book.isDisukai()) {
//                favBooksList.add(book);
//            }
//        }
//        booksAdapter = new BooksAdapter(requireContext(), favBooksList);
//        rvFav.setAdapter(booksAdapter);


//    public void onResume() {
//        super.onResume();
//        // Refresh isi list
//        if (getView() != null) {
//            onCreateView(LayoutInflater.from(getContext()), (ViewGroup) getView().getParent(), null);
//        }
//    }


//        ArrayList<Books> favBooksList = new ArrayList<>();
//        for (Books book : DataSource.generateBooks(requireContext())) {
//            if (book.isDisukai()) {
//                favBooksList.add(book);
//            }
//        }
//        BooksAdapter booksAdapter = new BooksAdapter(requireContext(), favBooksList);
//        rvFav.setAdapter(booksAdapter);
