package com.example.tp4;


import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.SearchView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {
    private RecyclerView rvBooks;
    private BooksAdapter booksAdapter;
    private ArrayList<Books> booksList;
    private SearchView pencarian;
//    private SearchView searchView;
//    EditText pencarianEditText;

    private RadioGroup rgGenre;
    private Button btnPilihGenre;
    private String selectedGenre = "Semua";
    private EditText etGenre;
    private ImageButton cancelGenre;


    private ProgressBar progressBar;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        rvBooks = view.findViewById(R.id.rv_books);

        booksList = DataSource.generateBooks(requireContext());

        GridLayoutManager gridLayoutManager = new GridLayoutManager(requireContext(), 2);
        rvBooks.setLayoutManager(gridLayoutManager);

        booksAdapter = new BooksAdapter(requireContext(), booksList);
        rvBooks.setAdapter(booksAdapter);

        etGenre = view.findViewById(R.id.et_genre);
        progressBar = view.findViewById(R.id.progressBar_home);


        pencarian = view.findViewById(R.id.pencarian);
        pencarian.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
//                filterList(newText, booksAdapter);
                filterList(newText);
                return true;
            }
        });


        btnPilihGenre = view.findViewById(R.id.btn_pilih_genre);
        btnPilihGenre.setOnClickListener(v -> showSheetGenre());

        cancelGenre = view.findViewById(R.id.cancel_genre);
        cancelGenre.setOnClickListener(v -> {
            selectedGenre = "Semua";
            etGenre.setText(selectedGenre);
            filterList(pencarian.getQuery().toString());
            pencarian.setQuery("", false);
        });


        return view;
    }

    private void showSheetGenre() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireContext());
        View sheetView = LayoutInflater.from(getContext()).inflate(R.layout.sheet_genre, null);
        bottomSheetDialog.setContentView(sheetView);

        RadioGroup rgGenre = sheetView.findViewById(R.id.rg_genre);

        rgGenre.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rb_fiksi) {
                selectedGenre = "Fiksi";
            } else if (checkedId == R.id.rb_nonfiksi) {
                selectedGenre = "Non-Fiksi";
            } else if (checkedId == R.id.rb_biografi) {
                selectedGenre = "Biografi";
            } else if (checkedId == R.id.rb_novel) {
                selectedGenre = "Novel";
            } else if (checkedId == R.id.rb_cerpen) {
                selectedGenre = "Cerpen";
            } else if (checkedId == R.id.rb_politik) {
                selectedGenre = "Politik";
            } else if (checkedId == R.id.rb_komik) {
                selectedGenre = "Komik";
            } else if (checkedId == R.id.rb_fantasi) {
                selectedGenre = "Fantasi";
            } else if (checkedId == R.id.rb_horor) {
                selectedGenre = "Horror";
            } else if (checkedId == R.id.rb_romansa) {
                selectedGenre = "Romansa";
            } else if (checkedId == R.id.rb_misteri) {
                selectedGenre = "Misteri";
            } else if (checkedId == R.id.rb_sejarah) {
                selectedGenre = "Sejarah";
            } else if (checkedId == R.id.rb_sains) {
                selectedGenre = "Sains";
            } else {
                selectedGenre = "Semua";
            }


            String currentQuery = pencarian.getQuery().toString();
            filterList(currentQuery);


            etGenre.setText(selectedGenre);

            bottomSheetDialog.dismiss();
        });

        bottomSheetDialog.show();
    }

    private void filterList(String keyword) {
        showLoading(true);

        executor.execute(() -> {
            ArrayList<Books> filteredList = new ArrayList<>();
            for (Books book : booksList) {
                boolean cocokJudul = book.getJudul().toLowerCase().contains(keyword.toLowerCase());
                boolean cocokGenre = selectedGenre.equals("Semua") || book.getGenre().equalsIgnoreCase(selectedGenre);
                if (cocokJudul && cocokGenre) {
                    filteredList.add(book);
                }
            }

            
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            handler.post(() -> {
                booksAdapter.updateData(filteredList);
                showLoading(false);
            });
        });
    }

    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        rvBooks.setVisibility(isLoading ? View.GONE : View.VISIBLE);
    }


}



//    private void filterList(String keyword) {
//        ArrayList<Books> filteredList = new ArrayList<>();
//        for (Books book : booksList) {
//            boolean cocokJudul = book.getJudul().toLowerCase().contains(keyword.toLowerCase());
//            boolean cocokGenre = selectedGenre.equals("Semua") || book.getGenre().equalsIgnoreCase(selectedGenre);
//            if (cocokJudul && cocokGenre) {
//                filteredList.add(book);
//            }
//        }
//        booksAdapter.updateData(filteredList);
//    }
//        ArrayList<Books> filteredList = new ArrayList<>();
//        for (Books book : booksList) {
//            if (book.getJudul().toLowerCase().contains(text.toLowerCase())) {
//                filteredList.add(book);
//            }
//        }
//

//        pencarianEditText = pencarian.findViewById(androidx.appcompat.R.id.search_src_text);
//
//        if (pencarianEditText != null) {
//            pencarianEditText.setTextColor(Color.BLACK);
//            pencarianEditText.setHintTextColor(Color.GRAY);
//        }

//        pencarian.post(() -> {
//            EditText searchEditText = pencarian.findViewById(androidx.appcompat.R.id.search_src_text);
//            if (searchEditText != null) {
//                searchEditText.setTextColor(Color.BLACK);        // warna teks input
//                searchEditText.setHintTextColor(Color.GRAY);     // warna hint
//            }
//        });