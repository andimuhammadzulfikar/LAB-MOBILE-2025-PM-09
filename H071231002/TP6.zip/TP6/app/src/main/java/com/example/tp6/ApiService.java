package com.example.tp6;

import retrofit2.http.GET;
import retrofit2.Call;
import retrofit2.http.Query;

public interface ApiService {
    @GET("api/character")
    Call<KarakterResponse> getKarakter(@Query("page") int page);
}
