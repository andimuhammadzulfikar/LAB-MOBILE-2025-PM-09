package com.example.tp6;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Karakter implements Parcelable {
    private int id;
    private String name, status, species, type, gender, image;


    public Karakter(int id, String name, String status, String species, String type, String gender, String image) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.species = species;
        this.type = type;
        this.gender = gender;
        this.image = image;
    }

    protected Karakter(Parcel in) {
        id = in.readInt();
        name = in.readString();
        status = in.readString();
        species = in.readString();
        type = in.readString();
        gender = in.readString();
        image = in.readString();
    }

    public static final Creator<Karakter> CREATOR = new Creator<Karakter>() {
        @Override
        public Karakter createFromParcel(Parcel in) {
            return new Karakter(in);
        }

        @Override
        public Karakter[] newArray(int size) {
            return new Karakter[size];
        }
    };

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getSpecies() {
        return species;
    }

    public String getType() {
        return type;
    }

    public String getGender() {
        return gender;
    }

    public String getImage() {
        return image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(status);
        parcel.writeString(species);
        parcel.writeString(type);
        parcel.writeString(gender);
        parcel.writeString(image);
    }
}
