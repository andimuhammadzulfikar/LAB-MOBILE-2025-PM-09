package com.example.tp6;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class KarakterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_ITEM = 0;
    private static final int TYPE_FOOTER = 1;

    private List<Karakter> karakterList = new ArrayList<>();
    private boolean showFooter = false;

    private Context context;

    public KarakterAdapter(Context context) {
        this.context = context;
    }

    public void addAll(List<Karakter> list) {
        int start = karakterList.size();
        karakterList.addAll(list);
        notifyItemRangeInserted(start, list.size());
    }

    public void showFooter(boolean show) {
        showFooter = show;
        notifyItemChanged(getItemCount() - 1);
    }

    @Override
    public int getItemViewType(int position) {
        if (position == karakterList.size()) {
            return TYPE_FOOTER;
        }
        return TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return karakterList.size() + (showFooter ? 1 : 0);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.karakter_item, parent, false);
            return new KarakterViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.btn_more, parent, false);
            return new FooterViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof KarakterViewHolder) {
            Karakter karakter = karakterList.get(position);
            ((KarakterViewHolder) holder).bind(karakter);
        } else if (holder instanceof FooterViewHolder) {
            ((FooterViewHolder) holder).btnMore.setOnClickListener(v -> {
                if (listener != null) listener.onLoadMore();
            });
        }
    }

    class KarakterViewHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView tvName, tvSpesies;
        KarakterViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.nama_karakter);
            tvSpesies = itemView.findViewById(R.id.spesies_karakter);
            img = itemView.findViewById(R.id.image_karakter);

        }
        void bind(Karakter karakter) {
            Picasso.get().load(karakter.getImage()).into(img);
            tvSpesies.setText(karakter.getSpecies());
            tvName.setText(karakter.getName());

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, DetailKarakter.class);
                intent.putExtra("karakter", karakter);
                context.startActivity(intent);
            });

        }
    }

    class FooterViewHolder extends RecyclerView.ViewHolder {
        MaterialButton btnMore;
        FooterViewHolder(View itemView) {
            super(itemView);
            btnMore = itemView.findViewById(R.id.btn_more);
        }
    }

    // Load More Listener
    public interface OnLoadMoreListener {
        void onLoadMore();
    }

    private OnLoadMoreListener listener;
    public void setOnLoadMoreListener(OnLoadMoreListener listener) {
        this.listener = listener;
    }
}







//public class KarakterAdapter extends RecyclerView.Adapter<KarakterAdapter.UserViewHolder>{
//    public List<Karakter> karakterList;
//
//    public KarakterAdapter(List<Karakter> karakterList) {
//        this.karakterList = karakterList;
//    }
//
//    @NonNull
//    @Override
//    public KarakterAdapter.UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.karakter_item, parent, false);
//        return new UserViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull KarakterAdapter.UserViewHolder holder, int position) {
//        Karakter karakter = karakterList.get(position);
//        holder.bind(karakter);
//    }
//
//    @Override
//    public int getItemCount() {
//        return karakterList.size();
//    }
//
//    public void addAll(List<Karakter> karakterList) {
//        int startPosition = this.karakterList.size();
//        this.karakterList.addAll(karakterList);
//        notifyItemRangeInserted(startPosition, karakterList.size());
//    }
//
//    public class UserViewHolder extends RecyclerView.ViewHolder {
//        private ImageView img;
//        private TextView nama, spesies;
//
//        public UserViewHolder(@NonNull View itemView) {
//            super(itemView);
//            img = itemView.findViewById(R.id.image_karakter);
//            nama = itemView.findViewById(R.id.nama_karakter);
//            spesies = itemView.findViewById(R.id.spesies_karakter);
//        }
//
//        public void bind(Karakter karakter) {
//            Picasso.get().load(karakter.getImage()).into(img);
//            nama.setText(karakter.getName());
//            spesies.setText(karakter.getSpecies());
//        }
//    }
//}
