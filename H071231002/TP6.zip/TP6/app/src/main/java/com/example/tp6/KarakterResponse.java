package com.example.tp6;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class KarakterResponse {
    @SerializedName("results")
    private List<Karakter> results;

    @SerializedName("info")
    private Info info;

    public KarakterResponse(List<Karakter> data) {
        this.results = data;
    }

    public Info getInfo() {
        return info;
    }

    public List<Karakter> getData() {
        return results;
    }

    public void setData(List<Karakter> data) {
        this.results = data;
    }

}