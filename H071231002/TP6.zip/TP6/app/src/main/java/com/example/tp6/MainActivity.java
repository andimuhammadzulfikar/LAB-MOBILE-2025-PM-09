package com.example.tp6;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvKarakter;
    private MaterialButton btnMore;
    private TextView tvError;
    private ImageView ivReload;
    private KarakterAdapter karakterAdapter;

    private ApiService apiService;

    private int currentPage = 1;
    private boolean isLastPage = false;

    private ProgressBar progressBar;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Handler handler = new Handler(Looper.getMainLooper());



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rvKarakter = findViewById(R.id.rv_karakter);
        progressBar = findViewById(R.id.progressBar_home);
        tvError = findViewById(R.id.tv_error);
        ivReload = findViewById(R.id.iv_reload);

        apiService = ApiConfig.getInstance().create(ApiService.class);

        karakterAdapter = new KarakterAdapter(MainActivity.this);
        rvKarakter.setLayoutManager(new LinearLayoutManager(this));
        rvKarakter.setAdapter(karakterAdapter);

        karakterAdapter.setOnLoadMoreListener(() -> {
            currentPage++;
            loadKarakter(currentPage);
        });


        // Load data pertama kali


        if (!isNetworkAvailable()) {
            // TIDAK ADA INTERNET
            showError(true);
        } else {
            showLoading(true);
            executor.execute(() -> {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                handler.post(() -> {
                    loadKarakter(currentPage);
                });
            });
        }

        ivReload.setOnClickListener(v -> {
            if (isNetworkAvailable()) {
                showError(false);
                showLoading(true);
                loadKarakter(currentPage);
            } else {
                Toast.makeText(MainActivity.this, "Masih tidak ada koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnected();
    }
    private void showError(boolean isError) {
        tvError.setVisibility(isError ? View.VISIBLE : View.GONE);
        ivReload.setVisibility(isError ? View.VISIBLE : View.GONE);
        rvKarakter.setVisibility(isError ? View.GONE : View.VISIBLE);
        progressBar.setVisibility(View.GONE);
    }



    private void showLoading(boolean isLoading) {
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        rvKarakter.setVisibility(isLoading ? View.GONE : View.VISIBLE);
    }

    private void loadKarakter(int halaman) {
        Call<KarakterResponse> request = apiService.getKarakter(halaman);
        request.enqueue(new Callback<KarakterResponse>() {
            @Override
            public void onResponse(Call<KarakterResponse> call, Response<KarakterResponse> response) {
                showLoading(false);

                if (response.isSuccessful()) {
                    List<Karakter> karakterList = response.body().getData();

                    karakterAdapter.addAll(karakterList);

                    boolean hasNext = response.body().getInfo().getNext() != null;
                    karakterAdapter.showFooter(hasNext);
                }
            }

            @Override
            public void onFailure(Call<KarakterResponse> call, Throwable t) {
                showLoading(false);
                showError(true);
                Toast.makeText(MainActivity.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}


//                    if (karakterAdapter == null) {
//                        karakterAdapter = new KarakterAdapter(MainActivity.this);
//
//                        karakterAdapter.setOnLoadMoreListener(() -> {
//                            currentPage++;
//                            showLoading(true);
//                            loadKarakter(currentPage);
//                        });
////                        karakterAdapter.addAll(karakterList);
//                        rvKarakter.setAdapter(karakterAdapter);
//                    }



//        btnMore.setOnClickListener(v -> {
//            if (!isLastPage) {
//                currentPage++;
//                showLoading(true);
//                loadKarakter(currentPage);
//            }
//        });


//        loadKarakter(currentPage);



//                    if (response.isSuccessful() && response.body() != null) {
//                    KarakterResponse body = response.body();
//                    List<Karakter> karakterList = body.getData();
//
//                    // Inisialisasi adapter jika pertama kali
//                    if (karakterAdapter == null) {
//                        karakterAdapter = new KarakterAdapter(new ArrayList<>());
//                        rvKarakter.setAdapter(karakterAdapter);
//                    }
//
//                    karakterAdapter.addAll(karakterList);
//
//                    // Cek apakah ada halaman selanjutnya
//                    if (body.getInfo() != null && body.getInfo().getNext() == null) {
//                        isLastPage = true;
//                        btnMore.setVisibility(View.GONE);
//                    } else {
//                        btnMore.setVisibility(View.VISIBLE);
//                    }
//                }


//                    if (karakterList.isEmpty()) {
//                        isLastPage = true;
//                    } else {
//                        currentPage++;
//                    }


//                    if (karakterAdapter == null) {
//                        karakterAdapter = new KarakterAdapter(karakterList);
//                        rvKarakter.setAdapter(karakterAdapter);
//                    }
//
//                    karakterAdapter.addAll(karakterList);


//        Call<KarakterResponse> request = apiService.getKarakter();
//        request.enqueue(new Callback<KarakterResponse>() {
//            @Override
//            public void onResponse(Call<KarakterResponse> call, Response<KarakterResponse> response) {
//                if (response.isSuccessful()) {
//                    List<Karakter> karakterList = response.body().getData();
//
//
//                    karakterAdapter = new KarakterAdapter(karakterList);
//                    rvKarakter.setAdapter(karakterAdapter);
//                }
//            }
//
//            @Override
//            public void onFailure(Call<KarakterResponse> call, Throwable t) {
//
//            }
//        });