package com.example.tp8;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BuatNote extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private MaterialButton btnBack, btnSimpan;
    private TextInputEditText judul, isi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_buat_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btn_back);
        btnSimpan = findViewById(R.id.btn_simpan);
        judul = findViewById(R.id.input_judul);
        isi = findViewById(R.id.input_isi);

        btnSimpan.setOnClickListener(v -> {
            String judul = String.valueOf(this.judul.getText());
            String isi = String.valueOf(this.isi.getText());

            dbHelper = new DatabaseHelper(BuatNote.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("title", judul);
            values.put("content", isi);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String now = sdf.format(new Date());

            values.put("created_at", now);
            values.put("updated_at", now);

            long hasil = db.insert("notes", null, values);
            if (hasil != -1) {
                Intent resulIntent = new Intent();
                setResult(101, resulIntent);
                Toast.makeText(BuatNote.this, "Berhasil Membuat Note", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(BuatNote.this, "Gagal Membuat Note", Toast.LENGTH_SHORT).show();
            }
            db.close();

        });

    }

    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle("Perhatian!");
        dialog.setMessage("Semua perubahan yang belum disimpan akan hilang. Yakin ingin keluar?");
        dialog.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_dialog));

        dialog.setPositiveButton("Keluar", (d, which) -> {
            // Jika pengguna memilih "Keluar"
            if (isTaskRoot()) {
                // Jika ini activity utama, tambahkan animasi
                finishAffinity();
                System.exit(0);
            } else {
                super.onBackPressed();
            }
        });

        dialog.setNegativeButton("Batal", (d, which) -> d.dismiss());

        dialog.setOnCancelListener(d -> {
            Toast.makeText(this, "Aksi dibatalkan", Toast.LENGTH_SHORT).show();
        });

        dialog.show();
    }
}