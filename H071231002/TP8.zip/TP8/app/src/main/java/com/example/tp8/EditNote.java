package com.example.tp8;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EditNote extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private MaterialButton btnHapus, btnBack, btnEdit;
    private TextInputEditText judul, isi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        btnHapus = findViewById(R.id.btn_hapus);
        btnBack = findViewById(R.id.btn_back);
        btnEdit = findViewById(R.id.btn_edit);
        judul = findViewById(R.id.edit_judul);
        isi = findViewById(R.id.edit_isi);


        int noteId = getIntent().getIntExtra("id", -1);


        if (noteId != -1) {
            dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.query("notes", null, "id = ?", new String[]{String.valueOf(noteId)}, null, null, null);

            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String judulNote = cursor.getString(cursor.getColumnIndex("title"));
                @SuppressLint("Range") String isiNote = cursor.getString(cursor.getColumnIndex("content"));


                judul.setText(judulNote);
                isi.setText(isiNote);
            }

            cursor.close();
            db.close();
        }



        btnEdit.setOnClickListener(v -> {
            String judulEdit = String.valueOf(judul.getText());
            String isiEdit = String.valueOf(isi.getText());

            dbHelper = new DatabaseHelper(EditNote.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("title", judulEdit);
            values.put("content", isiEdit);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String now = sdf.format(new Date());
            values.put("updated_at", now);

            long hasil = db.update("notes", values, "id = ?", new String[]{String.valueOf(noteId)});

            if (hasil != -1) {
                Intent resulIntent = new Intent();
                setResult(101, resulIntent);
                Toast.makeText(EditNote.this, "Berhasil Mengedit Note", Toast.LENGTH_SHORT).show();
                finish();
            }else {
                Toast.makeText(EditNote.this, "Gagal Mengedit Note", Toast.LENGTH_SHORT).show();
            }
            db.close();
        });

        btnHapus.setOnClickListener(v -> {
            MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
            dialog.setTitle("Konfirmasi Hapus Note");
            dialog.setMessage("Apakah Anda yakin ingin menghapus note ini?");
            dialog.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_dialog));

            dialog.setPositiveButton("Ya", (d, which) -> {
                dbHelper = new DatabaseHelper(EditNote.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                long hasil = db.delete("notes", "id = ?", new String[]{String.valueOf(noteId)});
                if (hasil != -1) {
                    Intent resulIntent = new Intent();
                    setResult(101, resulIntent);
                    Toast.makeText(EditNote.this, "Berhasil Menghapus Note", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(EditNote.this, "Gagal Menghapus Note", Toast.LENGTH_SHORT).show();
                }
                db.close();
            });

            dialog.setNegativeButton("Tidak", (d, which) -> {
                d.dismiss();
            });

            dialog.show();
        });

        btnBack.setOnClickListener(v -> {
            MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
            dialog.setTitle("Perhatian!");
            dialog.setMessage("Semua perubahan yang belum disimpan akan hilang. Yakin ingin keluar?");
            dialog.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_dialog));

            dialog.setPositiveButton("Ya", (d, which) -> {
                super.onBackPressed();
            });

            dialog.setNegativeButton("Tidak", (d, which) -> {
                d.dismiss();
            });

            dialog.show();
        });



    }
    @Override
    public void onBackPressed() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle("Perhatian!");
        dialog.setMessage("Semua perubahan yang belum disimpan akan hilang. Yakin ingin keluar?");
        dialog.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_dialog));

        dialog.setPositiveButton("Keluar", (d, which) -> {
            if (isTaskRoot()) {
                finishAffinity();
                System.exit(0);
            } else {
                super.onBackPressed();
            }
        });

        dialog.setNegativeButton("Batal", (d, which) -> d.dismiss());

        dialog.show();
    }
}