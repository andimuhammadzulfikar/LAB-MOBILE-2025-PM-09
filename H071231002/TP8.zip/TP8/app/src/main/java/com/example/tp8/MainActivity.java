package com.example.tp8;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.SearchView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private NoteAdapter adapter;

    private RecyclerView recyclerView;
    private MaterialButton btnTambah;
    private SearchView pencarian;




    final ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == 101){
                    getData();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        deleteDatabase("notes.db");

        recyclerView = findViewById(R.id.rv_notes);
        btnTambah = findViewById(R.id.btnTambah);
        pencarian = findViewById(R.id.pencarian);

        dbHelper = new DatabaseHelper(MainActivity.this);

        adapter = new NoteAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        getData();

        btnTambah.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BuatNote.class);
            resultLauncher.launch(intent);
        });

        adapter.setOnNoteClickListener(note -> {
            Intent intent = new Intent(MainActivity.this, EditNote.class);
            intent.putExtra("id", note.getId());
            resultLauncher.launch(intent);
        });



    }

    private void getData() {
        dbHelper = new DatabaseHelper(MainActivity.this);
        List<Note> notesList = new ArrayList<>();;
        SQLiteDatabase db =dbHelper.getReadableDatabase();

        Cursor cursor = db.query("notes", null, null, null, null, null, null);

        if (cursor.moveToFirst()){
            do{
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String judul = cursor.getString(cursor.getColumnIndex("title"));
                @SuppressLint("Range") String isi = cursor.getString(cursor.getColumnIndex("content"));
                @SuppressLint("Range") String createdAt = cursor.getString(cursor.getColumnIndex("created_at"));
                @SuppressLint("Range") String updatedAt = cursor.getString(cursor.getColumnIndex("updated_at"));

                Log.d("WAKTU_DEBUG", "created_at: " + createdAt + ", updated_at: " + updatedAt);

                Note note = new Note(id, judul, isi, createdAt, updatedAt);
                notesList.add(note);

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        adapter.setNotesList(notesList);

    }

}