package com.example.tp8;

public class Note {
    private int id;
    private String title;
    private String isi;
    private String createdAt;
    private String updatedAt;


    public Note(int id, String title, String isi, String createdAt, String updatedAt) {
        this.id = id;
        this.title = title;
        this.isi = isi;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getIsi() {
        return isi;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }
}
