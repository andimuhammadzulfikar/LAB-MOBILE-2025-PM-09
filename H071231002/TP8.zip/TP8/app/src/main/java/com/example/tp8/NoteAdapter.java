package com.example.tp8;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.viewHolder> {
    private List<Note> notesList;

    public NoteAdapter(List<Note> notesList) {
        this.notesList = notesList;
    }

    @NonNull
    @Override
    public NoteAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notes_item, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteAdapter.viewHolder holder, int position) {
        Note note = notesList.get(position);

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date createdDate = sdf.parse(note.getCreatedAt());
            Date updatedDate = sdf.parse(note.getUpdatedAt());

            SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault());

            String formattedCreated = displayFormat.format(createdDate);
            String formattedUpdated = displayFormat.format(updatedDate);

            if (!formattedUpdated.equals(formattedCreated)) {
                holder.waktu.setText("Diperbarui: " + formattedUpdated);
            } else {
                holder.waktu.setText("Dibuat: " + formattedCreated);
            }
        } catch (Exception e) {
            e.printStackTrace();
            holder.waktu.setText("Waktu tidak valid");
        }

        holder.judul.setText(note.getTitle());
        holder.isi.setText(note.getIsi());

        holder.itemView.setOnClickListener(v -> {
            if (noteClickListener != null) {
                noteClickListener.onNoteClick(note);
            }
        });
    }


    @Override
    public int getItemCount() {
        return notesList.size();
    }


    public class viewHolder extends RecyclerView.ViewHolder {
        TextView judul, isi, waktu;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            judul = itemView.findViewById(R.id.tv_judul);
            isi = itemView.findViewById(R.id.tv_isi);
            waktu = itemView.findViewById(R.id.tv_waktu);
        }
    }

    //ini untuk perbarui adapter setiap ditambah item
    public void setNotesList(List<Note> notesList) {
        this.notesList = notesList;
        notifyDataSetChanged();
    }

    public interface OnNoteClickListener {
        void onNoteClick(Note note);
    }

    private OnNoteClickListener noteClickListener;

    public void setOnNoteClickListener(OnNoteClickListener listener) {
        this.noteClickListener = listener;
    }



}
